import{c as r,s as e}from"./flowDiagram-23GEKE2U-Cru4QS_K.js";import{_ as a}from"./mermaid.core-B-UqLzZT.js";import"./chunk-5VM5RSS4-CtoP0dVk.js";import"./chunk-XXDRQBXY-BharuYee.js";import"./chunk-VR4S4FIN-BiChsZSM.js";import"./chunk-32BRIVSS-CVmgZ5Qi.js";import"./MarkdownReader-DyDeQEPP.js";import"./react-runtime-CUbl_rHH.js";import"./index-C8ZB6Nqm.js";import"./data-runtime-DiihZ4CY.js";import"./channel-Wjr1dRgy.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,g=r({defaultLayout:"swimlane",styles:m});export{g as diagram};
